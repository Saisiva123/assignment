import { Injectable } from '@angular/core';
import { Details } from '../models/cardDetails.interface';
import { HttpClient } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class ExecService {

  url;

  constructor(private http:HttpClient) { }

  submitCardDetails(data:Details)
  {
    console.log("details were ",data);
    
    return 
    //this.http.post(this.url,data);
  }
}
