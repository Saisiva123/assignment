import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomePageComponent } from './components/home-page/home-page.component';
import { CardDetailsFormComponent } from './components/card-details-form/card-details-form.component';

const routes: Routes = [
  {
    path:'',redirectTo:'/homePage',pathMatch:'full'
  },
  {
    path:'homePage',component:HomePageComponent
  },
  {
    path:'cardForm',component:CardDetailsFormComponent
  },
  {
    path:"**",redirectTo:'/homePage'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routeComponents = [HomePageComponent,CardDetailsFormComponent]