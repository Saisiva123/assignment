export interface Details
{
    cardNumber:String;
    cardHolder:String;
    cardExpectationDate:string;
    cardSecurityCode:String;
    cardAmount:String;
}