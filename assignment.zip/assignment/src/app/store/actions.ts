import { Details } from "../models/cardDetails.interface";

export enum ActionTypes
{
    ADD_CARD_DETAILS = "ADD ITEM"
}
export class AddCarddDetailsAction 
{
    readonly type = ActionTypes.ADD_CARD_DETAILS;
    constructor(public payload:Details)
    {

    }
}
export type actions = AddCarddDetailsAction;