import { Details } from "../models/cardDetails.interface";
import { actions } from "./actions";

const initState:Array<Details> = [{

    cardNumber:"123 456 789",
    cardHolder:"Sai",
    cardExpectationDate:"03-16-1999",
    cardSecurityCode:"123",
    cardAmount:"100000"

}];
export function CardReducer(state:Array<Details> = initState,action:actions)
{
    switch(action.type)
    {
        case "ADD ITEM" : return [...state,action.payload];
        default : return state;
    }
}