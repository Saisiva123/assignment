import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Details } from '../../models/cardDetails.interface';
import { ExecService } from "../../services/exec.service";
import { Store } from '@ngrx/store';
import { AddCarddDetailsAction } from 'src/app/store/actions';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-card-details-form',
  templateUrl: './card-details-form.component.html',
  styleUrls: ['./card-details-form.component.css']
})

export class CardDetailsFormComponent implements OnInit {

  cardDetails: FormGroup;
  submitted = false;
  minDate = new Date();

  constructor(private fb: FormBuilder,private execService:ExecService,private store:Store,private toastr: ToastrService) { }

  ngOnInit(): void {
    this.cardDetails = this.fb.group(
      {
        number: ['', Validators.required],
        holder: ['', Validators.required],
        date: ['', Validators.required],
        secCode: ['', Validators.maxLength(3)],
        amount: ['', Validators.required]
      }
    );
  }
  submitCardDetails() {
    this.submitted = true;
    if(this.cardDetails.valid)
    {
      //this.toastr.success('successfully submitted', 'Success!');
      alert("Successfully submitted");
      let details:Details={
        cardNumber : this.details.number.value,
        cardHolder : this.details.holder.value,
        cardExpectationDate :  this.details.date.value.getDate()+"-"+( this.details.date.value.getMonth()+1)+"-"+ this.details.date.value.getFullYear(),
        cardSecurityCode  :this.details.secCode.value,
        cardAmount : this.details.amount.value
      };
      this.store.dispatch(new AddCarddDetailsAction(details));

      // Since we dont have url , Im not calling this api

      // this.execService.submitCardDetails(details).subscribe(res=>{
      //   console.log("res",res);
      // })

    }
  }
  clearData(value)
  {
    this.cardDetails.controls[value].setValue('');
  }
  get details() {
    return this.cardDetails.controls;
  }

}
